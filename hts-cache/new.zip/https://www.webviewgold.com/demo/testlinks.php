<a href='https://www.google.com'>Link 1 (default)</a><br>
<a href='https://www.google.com' target="_blank">Link 2 (target="_blank")</a><br>
<a href='https://www.google.com' target="_self">Link 3 (target="_self")</a><br>
<a href='#' onClick="window.location.href='https://www.google.com';">Link 4 (window.location.href)</a><br>
<a href='#' onClick="window.location='https://www.google.com';">Link 5 (window.location)</a><br>
<a href='#' onClick="top.location.href='https://www.google.com';">Link 6 (top.location.href)</a><br>
<a href='#' onClick="top.location='https://www.google.com';">Link 7 (top.location)</a><br>
<a href='#' onClick="window.open('https://www.google.com');">Link 8 (window.open)</a><br>